================================================================================
 MW3 Native Controller Support (Campaign & Survival)
 PRE-ALPHA v0.1.0 -- 2026-07-15
================================================================================

  ****************************************************************************
  * THIS IS EXPERIMENTAL, PRE-ALPHA SOFTWARE.                                *
  * It hooks directly into a live game process. Expect bugs, rough edges,    *
  * unfinished features, and the occasional need to fall back to keyboard/   *
  * mouse. Use at your own risk. Not affiliated with, endorsed by, or        *
  * sponsored by Activision, Infinity Ward, or any of their affiliates.      *
  ****************************************************************************

--------------------------------------------------------------------------------
WHAT THIS IS
--------------------------------------------------------------------------------

A from-scratch native controller mod for Call of Duty: Modern Warfare 3 (2011,
IW5 engine). Analog movement, look, and most buttons are driven directly
through the game's own real engine calls -- not a keyboard/mouse-emulation
mapper. See the project's README.md and re_notes/ (in the source repo) for the
full reverse-engineering writeup.

Supported right now: CAMPAIGN and SURVIVAL only (iw5sp.exe).

--------------------------------------------------------------------------------
MULTIPLAYER IS NOT SUPPORTED -- DO NOT USE WITH iw5mp.exe
--------------------------------------------------------------------------------

This mod has ONLY been analyzed and tested against iw5sp.exe (Campaign/
Survival). iw5mp.exe (Multiplayer) is a completely separate binary that has
not been reverse-engineered at all -- none of this mod's hooks are expected to
find anything to hook there, but that has NOT been explicitly verified live,
and there is also an open, unresolved question about anti-cheat exposure from
running injected code alongside a VAC-protected online binary. Do not install
this alongside Multiplayer play until that's been explicitly addressed in a
future release.

--------------------------------------------------------------------------------
INSTALLATION
--------------------------------------------------------------------------------

1. Copy "d3d9.dll" from this zip into your MW3 install folder -- the same
   folder that contains iw5sp.exe (e.g.
   ...\SteamLibrary\steamapps\common\Call of Duty Modern Warfare 3\).
2. Launch the game and start a Campaign or Survival session as normal.
3. A log file, "proxy_d3d9.log", will appear in that same folder once the mod
   is running -- if something goes wrong, this file is the first thing to
   check, and the most useful thing to attach to a bug report.

UNINSTALLING: just delete "d3d9.dll" from the install folder. Nothing else is
modified; the base game files are never touched.

NOTE: Steam's "Verify integrity of game files" (or an automatic update) may
silently remove a dropped-in d3d9.dll. If controller input stops working after
an update, that's the likely reason -- just reinstall by repeating step 1.

--------------------------------------------------------------------------------
*** YOU WILL STILL NEED A KEYBOARD (AND LIKELY MOUSE) NEARBY ***
--------------------------------------------------------------------------------

Full controller-native menu/UI navigation is NOT implemented yet. There is no
controller cursor, no button-glyph prompts, and no in-game controller options
screen. In practice this means keyboard/mouse is still required for things
like:

  - The main menu, and any first-time setup/options screens
  - Buy stations in Survival
  - Opening the options/other menus during Survival's between-round pause
  - Any other menu, prompt, or UI element not explicitly listed as working in
    the control map below

This list is NOT guaranteed to be exhaustive -- this mod has not been through
exhaustive end-to-end testing across every menu/screen/mission in the game.
If you hit a screen or prompt that a controller doesn't respond to and isn't
mentioned above, that is an unknown/undiscovered gap, not a contradiction of
this notice -- keep a keyboard/mouse within reach at all times while playing,
just in case.

--------------------------------------------------------------------------------
WHAT WORKS (confirmed live, Campaign/Survival, iw5sp.exe)
--------------------------------------------------------------------------------

  - Analog movement (left stick) and analog look (right stick), own
    sensitivity curve, independent of the mouse pipeline
  - Fire (RT), Aim Down Sights (LT, true hold), Melee (R3)
  - Tactical (LB) / Lethal (RB), Jump (A)
  - Crouch/Prone 3-state stance ladder (B) -- tap vs. hold, like console
  - Interact + Reload (X, context-sensitive)
  - Sprint (L3) with a real 4-second-deplete / 2-second-cooldown stamina
    model, auto-standing from crouch/prone first
  - Weapon switch (Y)
  - Start: opens AND closes the real pause menu
  - D-pad (all 4 directions): killstreaks/attachments/loadout-dependent
    actionslots
  - Survival's between-wave "ready up" (hold Y for ~740ms) -- see the caveat
    below, this ONE feature works differently from everything else in the mod

--------------------------------------------------------------------------------
KNOWN LIMITATIONS, CAVEATS, AND OPEN BUGS
--------------------------------------------------------------------------------

  - BACK BUTTON: unassigned / does nothing. A first attempt caused a real
    regression (walked the player backward) and was reverted. Deprioritized.

  - KILLSTREAKS: only partially working. The Predator missile has been
    confirmed to partially function but needs further investigation; every
    other killstreak is untested. Since killstreaks matter a lot in Campaign,
    and Campaign testing has been much lighter than Survival testing so far,
    treat Campaign as the less-tested of the two supported modes.

  - SPRINT STAMINA OVERRIDES ARE INCOMPLETE: the 4s/2s stamina model is
    correctly bypassed (unlimited sprint) for a couple of specific Campaign
    missions confirmed so far to grant unlimited sprint natively -- but there
    may be others not yet found. Separately, the Extreme Conditioning perk
    (which should double sprint duration to ~8 seconds) is NOT yet accounted
    for at all -- expect the stock 4s/2s timing even with that perk equipped.

  - SURVIVAL READY-UP IS THE ONE NON-NATIVE SHORTCUT IN THE WHOLE MOD: after
    an extensive, multi-session search failed to find the real native trigger
    for Survival's "press F5 to ready up" prompt, holding Y instead sends a
    real synthetic F5 keypress to the game window. This has tested reliably,
    but it does mean: (a) it depends on F5 still being the game's own default
    ready-up key -- if you've personally rebound F5 to something else in your
    own keyboard controls, this will stop working correctly, and (b) it is a
    deliberate, documented exception to this mod's "no keyboard/mouse
    emulation" design, not the norm -- everything else in the mod drives the
    game's real internal state directly, with no synthetic key/mouse events
    at all.

  - NO CONTROLLER MENU/UI NAVIGATION: see the keyboard/mouse notice above.
    This also means no controller button-glyph prompts anywhere in the UI
    (prompts will still show keyboard/mouse icons even while playing with a
    controller).

  - NO AIM ASSIST YET: only deadzone shaping and a response curve are
    implemented on the stick input. Full console-style aim assist (rotational
    friction, target magnetism) is planned but not built.

  - NOT EXHAUSTIVELY TESTED: this is a pre-alpha, single-developer,
    from-scratch reverse-engineering project. It has been tested through
    real playtime, but not against every mission, every weapon, every
    killstreak, or every menu/UI flow in the game. Crashes, stuck states, or
    other unexpected behavior are possible. If the game becomes unresponsive
    to both controller AND keyboard/mouse input, that has happened at least
    once before during development (see the project's known_issues.md) and
    was fixed, but similar not-yet-discovered issues may still exist.

  - MULTIPLAYER (iw5mp.exe): not supported, not tested, see the dedicated
    warning above.

  - WINDOWS ONLY. Built for 32-bit (x86) targets specifically, matching the
    game's own binaries.

--------------------------------------------------------------------------------
REPORTING BUGS
--------------------------------------------------------------------------------

Please include: what you were doing, what you expected, what happened
instead, and the "proxy_d3d9.log" file from your install folder if the game
crashed or got stuck. See the project's GitHub repository for how to open an
issue, and CONTRIBUTING.md if you'd like to help fix something.

--------------------------------------------------------------------------------
LICENSE
--------------------------------------------------------------------------------

See the included LICENSE file. Summary: the mod's own source is free to use,
modify, and fork, but neither this project nor any fork/derivative of it may
ever be sold or charged for -- it must stay free for everyone. This is a
deliberate restriction that means the license does not meet the OSI's formal
"open source" definition (full details in LICENSE). This mod bundles MinHook
and the Hacker Disassembler Engine (HDE) 32/64 C, both under their own
license -- see the project's README.md Credits section and
proxy_d3d9/third_party/minhook/LICENSE.txt in the source repo for full terms.

This license does not grant any rights to Call of Duty: Modern Warfare 3
itself -- you need your own legitimate, separately-owned copy of the game to
use this mod.
================================================================================
