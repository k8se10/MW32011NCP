================================================================================
 MW3 Native Controller Support (Campaign & Survival)
 PRE-ALPHA v0.1.2 -- 2026-07-16
================================================================================

  ****************************************************************************
  * THIS IS EXPERIMENTAL, PRE-ALPHA SOFTWARE.                                *
  * It hooks directly into a live game process. Expect bugs, rough edges,    *
  * unfinished features, and the occasional need to fall back to keyboard/   *
  * mouse. Use at your own risk. Not affiliated with, endorsed by, or        *
  * sponsored by Activision, Infinity Ward, or any of their affiliates.      *
  ****************************************************************************

See PATCHNOTES.md for the full list of what changed since v0.1.0-prealpha,
including v0.1.1's fixes/features and v0.1.2's documentation-accuracy pass
(config system, button/stick layout presets, and hold-to-interact were already
shipped in v0.1.1 but never documented until this release).

--------------------------------------------------------------------------------
WHAT THIS IS
--------------------------------------------------------------------------------

A from-scratch native controller mod for Call of Duty: Modern Warfare 3 (2011,
IW5 engine). Analog movement, look, and most buttons are driven directly
through the game's own real engine calls -- not a keyboard/mouse-emulation
mapper. See the project's README.md and re_notes/ (in the source repo) for the
full reverse-engineering writeup.

Supported right now: CAMPAIGN and SURVIVAL only (iw5sp.exe).

--------------------------------------------------------------------------------
MULTIPLAYER IS NOT SUPPORTED -- DO NOT USE WITH iw5mp.exe
--------------------------------------------------------------------------------

This mod has ONLY been analyzed and tested against iw5sp.exe (Campaign/
Survival). iw5mp.exe (Multiplayer) is a completely separate binary that has
not been reverse-engineered at all -- none of this mod's hooks are expected to
find anything to hook there, but that has NOT been explicitly verified live,
and there is also an open, unresolved question about anti-cheat exposure from
running injected code alongside a VAC-protected online binary. Do not install
this alongside Multiplayer play until that's been explicitly addressed in a
future release.

--------------------------------------------------------------------------------
INSTALLATION
--------------------------------------------------------------------------------

1. Copy "d3d9.dll" from this zip into your MW3 install folder -- the same
   folder that contains iw5sp.exe (e.g.
   ...\SteamLibrary\steamapps\common\Call of Duty Modern Warfare 3\).
2. Launch the game and start a Campaign or Survival session as normal.
3. A log file, "proxy_d3d9.log", will appear in that same folder once the mod
   is running -- if something goes wrong, this file is the first thing to
   check, and the most useful thing to attach to a bug report.

UNINSTALLING: just delete "d3d9.dll" from the install folder. Nothing else is
modified; the base game files are never touched.

NOTE: Steam's "Verify integrity of game files" (or an automatic update) may
silently remove a dropped-in d3d9.dll. If controller input stops working after
an update, that's the likely reason -- just reinstall by repeating step 1.

--------------------------------------------------------------------------------
*** KEYBOARD/MOUSE: STILL REQUIRED, AND NOW A SECONDARY-PRIORITY INPUT PATH ***
--------------------------------------------------------------------------------

Full controller-native menu/UI navigation is NOT implemented yet. There is no
controller cursor, no button-glyph prompts, and no in-game controller options
screen. In practice this means keyboard/mouse is still REQUIRED for things
like:

  - The main menu, and any first-time setup/options screens
  - Buy stations in Survival
  - Opening the options/other menus during Survival's between-round pause
  - Back / scoreboard, and most killstreak call-ins (not yet controller-native)
  - Any other menu, prompt, or UI element not explicitly listed as working in
    the control map below

v0.1.1 fixed a real bug where the mod's own controller Sprint hooks could
silently break vanilla keyboard sprint (see PATCHNOTES.md). That bug is fixed,
but finding and fixing it is also why keyboard/mouse is now treated as a
secondary-priority input path going forward, not a first-class target verified
to the same bar as controller: it's no longer being actively re-tested to the
same standard controller features get with every change. This does NOT mean
keyboard/mouse support is being removed -- it remains genuinely required for
the areas listed above -- just that it's more likely than controller input to
have an undiscovered rough edge. Keep a keyboard within reach at all times
while playing.

This list is NOT guaranteed to be exhaustive -- this mod has not been through
exhaustive end-to-end testing across every menu/screen/mission in the game.

--------------------------------------------------------------------------------
WHAT WORKS (confirmed live, Campaign/Survival, iw5sp.exe)
--------------------------------------------------------------------------------

  - Analog movement (left stick) and analog look (right stick), own
    sensitivity curve, independent of the mouse pipeline. ADS zoom-aware look
    slowdown is configurable (see mw3ncp_config.ini below).
  - Fire (RT), Aim Down Sights (LT, true hold), Melee (R3)
  - Tactical (LB) / Lethal (RB), Jump (A)
  - Crouch/Prone 3-state stance ladder (B) -- tap vs. hold, like console
    (from Standing/Crouched, hold goes Prone; from Prone, hold stands back up;
    tap toggles Standing<->Crouched, or Prone->Crouched)
  - Interact (X) requires a HOLD (740ms default) -- a quick tap does nothing;
    Reload (a separate real kbutton on the same physical button) always fires
    instantly regardless
  - Sprint (L3) with a real 4-second-deplete / 2-second-cooldown stamina
    model, auto-standing from crouch/prone first
  - Weapon switch (Y)
  - Start: opens AND closes the real pause menu
  - B: while any menu is open, backs out one level / closes it (same real
    mechanism as ESC), on top of its normal crouch/prone role in gameplay --
    added in v0.1.1, not yet confirmed across every menu screen
  - D-pad (all 4 directions): killstreaks/attachments/loadout-dependent
    actionslots
  - Survival's between-wave "ready up" (hold Y for ~740ms) -- see the caveat
    below, this ONE feature works differently from everything else in the mod
  - CONFIGURABLE via "mw3ncp_config.ini" (self-generated next to d3d9.dll on
    first run, fully commented): look sensitivity, ADS slowdown strength,
    invert look, stance/interact/ready-up hold thresholds, sprint
    stamina/regen seconds, and OG console button/stick layout presets
    (Default/Tactical/Lefty/TacticalLefty button layouts;
    Default/Southpaw/Legacy/LegacySouthpaw stick layouts) plus an independent
    trigger-flip toggle. No live-reload yet -- restart the game after editing.
    See the project's README.md for the full key reference and per-preset
    tables.

--------------------------------------------------------------------------------
KNOWN LIMITATIONS, CAVEATS, AND OPEN BUGS
--------------------------------------------------------------------------------

  - BACK BUTTON: unassigned / does nothing. A first attempt caused a real
    regression (walked the player backward) and was reverted. Deprioritized.

  - KILLSTREAKS: only partially working. The Predator missile has been
    confirmed to partially function but needs further investigation; every
    other killstreak is untested. D-pad Left's squadmate call-in fails 100%
    of the time (turret call-ins work fine). Since killstreaks matter a lot in
    Campaign, and Campaign testing has been much lighter than Survival testing
    so far, treat Campaign as the less-tested of the two supported modes.

  - SPRINT'S REAL NATIVE ENGAGE-KBUTTON WAS SEARCHED FOR AND NOT FOUND: this
    release spent significant effort trying to replace the controller Sprint
    implementation's raw pm_flags-forcing with the same real
    KeyDown/KeyUp-kbutton mechanism ADS and Reload use, via three independent
    techniques. All three came back negative; the search is parked, not just
    paused. Controller Sprint keeps its existing (working) implementation.

  - SPRINT STAMINA OVERRIDES ARE INCOMPLETE: the 4s/2s stamina model is
    correctly bypassed (unlimited sprint) for a couple of specific Campaign
    missions confirmed so far to grant unlimited sprint natively -- but there
    may be others not yet found. Separately, the Extreme Conditioning perk
    (which should double sprint duration to ~8 seconds) is NOT yet accounted
    for at all -- expect the stock 4s/2s timing even with that perk equipped.

  - SURVIVAL READY-UP IS THE ONE NON-NATIVE SHORTCUT IN THE WHOLE MOD: after
    an extensive, multi-session search failed to find the real native trigger
    for Survival's "press F5 to ready up" prompt, holding Y instead sends a
    real synthetic F5 keypress to the game window. This has tested reliably,
    but it does mean: (a) it depends on F5 still being the game's own default
    ready-up key -- if you've personally rebound F5 to something else in your
    own keyboard controls, this will stop working correctly, and (b) it is a
    deliberate, documented exception to this mod's "no keyboard/mouse
    emulation" design, not the norm -- everything else in the mod drives the
    game's real internal state directly, with no synthetic key/mouse events
    at all.

  - NO CONTROLLER MENU/UI NAVIGATION BEYOND B/START: no controller cursor, no
    button-glyph prompts anywhere in the UI yet (prompts will still show
    keyboard/mouse icons even while playing with a controller) -- though the
    source art for controller glyphs has now been prepared internally, the
    actual in-game rendering isn't wired up yet. No in-game controller options
    screen (sensitivity/deadzone/invert-Y/layout are config-file-only for now,
    see mw3ncp_config.ini).

  - NO AIM ASSIST YET: only deadzone shaping and a response curve are
    implemented on the stick input. Full console-style aim assist (rotational
    friction, target magnetism) is planned but not built.

  - NOT EXHAUSTIVELY TESTED: this is a pre-alpha, from-scratch
    reverse-engineering project. It has been tested through real playtime,
    but not against every mission, every weapon, every killstreak, or every
    menu/UI flow in the game. Crashes, stuck states, or other unexpected
    behavior are possible.

  - MULTIPLAYER (iw5mp.exe): not supported, not tested, see the dedicated
    warning above.

  - WINDOWS ONLY. Built for 32-bit (x86) targets specifically, matching the
    game's own binaries.

--------------------------------------------------------------------------------
REPORTING BUGS
--------------------------------------------------------------------------------

Please include: what you were doing, what you expected, what happened
instead, and the "proxy_d3d9.log" file from your install folder if the game
crashed or got stuck. See the project's GitHub repository for how to open an
issue, and CONTRIBUTING.md if you'd like to help fix something.

--------------------------------------------------------------------------------
LICENSE
--------------------------------------------------------------------------------

See the included LICENSE file. Summary: the mod's own source is free to use,
modify, and fork, but neither this project nor any fork/derivative of it may
ever be sold or charged for -- it must stay free for everyone. This is a
deliberate restriction that means the license does not meet the OSI's formal
"open source" definition (full details in LICENSE). This mod bundles MinHook
and the Hacker Disassembler Engine (HDE) 32/64 C, both under their own
license -- see the project's README.md Credits section and
proxy_d3d9/third_party/minhook/LICENSE.txt in the source repo for full terms.

This license does not grant any rights to Call of Duty: Modern Warfare 3
itself -- you need your own legitimate, separately-owned copy of the game to
use this mod.
================================================================================
